package com;
public class MergeCluster{
	String cluster;
	int id;
public void setId(int id){
	this.id = id;
}
public int getId(){
	return id;
}
public void setCluster(String cluster){
	this.cluster = cluster;
}
public String getCluster(){
	return cluster;
}
}